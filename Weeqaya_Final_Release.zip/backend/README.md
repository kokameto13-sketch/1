# Central storage backend specification
Use one central Google Drive owned by the organization. Android must never contain a service-account key.
Active/ stores current maintenance. Archive/ stores ZIP archives.
When active storage reaches >=50% and a new month is added: select the oldest COMPLETED month, ZIP metadata + before/after photos, upload to Drive/Archive, verify the uploaded file, then delete only that completed month's active files. Never delete current/incomplete work.
A deployed authenticated backend is required for production cloud sync; its URL and credentials are environment configuration, not source code.
