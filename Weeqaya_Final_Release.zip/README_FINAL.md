# Weeqaya
Maintenance documentation Android project.
Includes Android app structure, before/after camera capture with JPEG compression, record fields, and GitHub Actions APK build.
Cloud production rule: central backend + Google Drive. At 50% usage when a new month is added, archive the oldest completed month as a verified ZIP to Drive before deleting its active copy. Current/incomplete months are never deleted.
Production cloud sync requires deployment of the backend and its authenticated endpoint; secrets must not be embedded in the APK.
