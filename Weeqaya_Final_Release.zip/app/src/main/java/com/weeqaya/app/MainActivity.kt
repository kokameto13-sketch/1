package com.weeqaya.app
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
class MainActivity: AppCompatActivity(){
 lateinit var month:EditText; lateinit var control:EditText; lateinit var bar:EditText; lateinit var distributor:EditText; lateinit var status:TextView
 var kind="before"; var before=0; var after=0
 val camera=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){r->if(r.resultCode==RESULT_OK){val b=r.data?.extras?.get("data") as? android.graphics.Bitmap ?:return@registerForActivityResult; val d=File(filesDir,"maintenance/${safe(month.text.toString())}/$kind");d.mkdirs();val f=File(d,SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(Date())+".jpg");FileOutputStream(f).use{b.compress(android.graphics.Bitmap.CompressFormat.JPEG,82,it)};if(kind=="before")before++ else after++;status.text="قبل: $before | بعد: $after"}}
 override fun onCreate(s:Bundle?){super.onCreate(s);val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(28,24,28,24);fun e(h:String)=EditText(this).apply{hint=h;setSingleLine(true);textSize=17f};val t=TextView(this).apply{text="Weeqaya – إدارة الصيانة";textSize=26f};month=e("شهر الصيانة");control=e("اسم الكنترول / الوحدة");bar=e("البار");distributor=e("اسم الموزع");val b=Button(this).apply{text="📷 صورة قبل الصيانة"};val a=Button(this).apply{text="📷 صورة بعد الصيانة"};val save=Button(this).apply{text="💾 حفظ السجل"};status=TextView(this).apply{text="ابدأ بإدخال البيانات";textSize=16f};b.setOnClickListener{kind="before";cam()};a.setOnClickListener{kind="after";cam()};save.setOnClickListener{save()};listOf(t,month,control,bar,distributor,b,a,save,status).forEach{l.addView(it)};setContentView(l)}
 fun cam(){if(checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.CAMERA),5);return};camera.launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE))}
 fun save(){if(month.text.isBlank()){status.text="اكتب الشهر أولًا";return};val d=File(filesDir,"maintenance/${safe(month.text.toString())}");d.mkdirs();File(d,"record.txt").writeText("month=${month.text}\ncontrol=${control.text}\nbar=${bar.text}\ndistributor=${distributor.text}\ncomplete=${before>0&&after>0}");status.text="تم حفظ السجل"}
 fun safe(s:String)=s.replace(Regex("[^\\p{L}\\p{N}_-]"),"_")
}
